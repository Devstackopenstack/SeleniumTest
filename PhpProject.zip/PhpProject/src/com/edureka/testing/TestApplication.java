package com.edureka.testing;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


/**
 * @author Priyaranjan Mohapatra
 *
 */
public class TestApplication {
	static WebDriver driver;
	//static File screenshot = null;
	static int count=1;
	static ExtentTest test;
	static ExtentReports report;
	static File screenshot = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File DriverDir = new File(System.getProperty("user.dir"), "Driver");
		/*System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\785990\\Desktop\\PhpProject\\Driver\\Chrome\\chromedriver.exe");*/
		System.setProperty("webdriver.chrome.driver",DriverDir.getAbsolutePath()+"\\Chrome\\chromedriver.exe");

		try {
			
			File screenShotLocation = getLocation();
			report = new ExtentReports(screenShotLocation+"\\TestResults.html");
			test = report.startTest("Simple PHP Website");
			driver = new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

			System.out.println("Open Browser");
			driver.get("http://13.59.1.73:8142/index.php");
			System.out.println("Open Simple PHP Website");
			driver.manage().window().maximize();
			websleep(3000);
			screenshot=new File( screenShotLocation+"/"+"Screenshot"+"_" + count+ ".jpg");
			writeToFile(getScreenshot(),screenshot );
			count++;
			test.log(LogStatus.PASS, test.addScreenCapture(screenshot.getAbsolutePath())+ " Open Simple PHP Website");
			System.out.println("Click on About Us");
			driver.findElement(By.xpath("//*[@id=\"About Us\"]")).click();
			//websleep(1000);
			
			screenshot=new File( screenShotLocation+"/"+"Screenshot"+"_" + count+ ".jpg");
			writeToFile(getScreenshot(), screenshot);
			count++;
			test.log(LogStatus.PASS, test.addScreenCapture(screenshot.getAbsolutePath())+" Click on About Us");
			
			System.out.println("Validating text on screen");
			String val = "Lorem Ipsum Dipsum is simply dummy";
			screenshot=new File( screenShotLocation+"/"+"Screenshot"+"_" + count+ ".jpg");
			writeToFile(getScreenshot(), screenshot);
			count++;
			if (verifyTextPresent(val)) {
				System.out.println(val + " Text Present on screen");
				test.log(LogStatus.PASS,  test.addScreenCapture(screenshot.getAbsolutePath())+val + " Text Present on screen");
			}else {
				System.out.println(val + " Text not Present on screen");
				test.log(LogStatus.FAIL,  test.addScreenCapture(screenshot.getAbsolutePath())+val + " Text not Present on screen");
			}

		} catch (Exception e) {
		}finally {
			try {
				if (driver != null) {
					driver.quit();
				}
				report.endTest(test);
				report.flush();
			} catch (Exception ex) {
				// TODO: handle exception
			}
		}

	}

	public static void websleep(int waitTime) {
		try {
			Thread.sleep(waitTime);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static boolean verifyTextPresent(String value) {
		boolean found = false;
		// String value = "Lorem Ipsum Dipsum is simply dummy";
		if (driver != null) {
			WebElement element = null;
			// try {

			// Wait for the element to be found and visible with the polling interval
			WebDriverWait wait = new WebDriverWait(driver, TimeUnit.MILLISECONDS.toSeconds(50000),
					TimeUnit.SECONDS.toMillis(2));
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"PID-ab2-pg\"]"))));
			element = driver.findElement(By.xpath("//*[@id=\"PID-ab2-pg\"]"));

			// Compare the text
			if (element.getText().contains(value)) {
				found = true;
			} else {
				found = false;
			}

		}
		return found;
	}
	
	private static File getLocation() {
		File location = null;
		Date date = new Date();
		File reportsDir = new File(System.getProperty("user.dir"), "Reports");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
		SimpleDateFormat timeFormat = new SimpleDateFormat("hh mm ss aaa");
		location = new File(new File(reportsDir, dateFormat.format(date)), timeFormat.format(date));
		if (!location.exists())
			location.mkdirs();
		return location;
	}
	
	public static boolean writeToFile(byte[] data, File file) {
		if (file != null) {
			try {
				System.out.println("Screen shot path: "+file.getAbsolutePath());
				FileOutputStream fos = new FileOutputStream(file);
				fos.write(data);
				fos.flush();
				fos.close();
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		return false;
	}
	
	public static byte[] getScreenshot() {
		if (driver != null) {
			try {
				byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
				return screenshot;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

}
